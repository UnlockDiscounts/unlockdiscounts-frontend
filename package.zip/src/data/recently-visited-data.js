import image from "../assets/cloths.png";

const recently_visited_data = [
	{
		image: image,
		company: "Zara",
		type: "Formal Suit",
		price: 1900,
		prevPrice: 2500,
		discount: 24,
		category: "Men",
	},
	{
		image: image,
		company: "Zara",
		type: "Formal Suit",
		price: 1900,
		prevPrice: 2500,
		discount: 24,
		category: "Men",
	},
	{
		image: image,
		company: "Zara",
		type: "Formal Suit",
		price: 1900,
		prevPrice: 2500,
		discount: 24,
		category: "Men",
	},
	{
		image: image,
		company: "Zara",
		type: "Formal Suit",
		price: 1900,
		prevPrice: 2500,
		discount: 24,
		category: "Men",
	},
	{
		image: image,
		company: "Zara",
		type: "Formal Suit",
		price: 1900,
		prevPrice: 2500,
		discount: 24,
		category: "Men",
	},
	{
		image: image,
		company: "Zara",
		type: "Formal Suit",
		price: 1900,
		prevPrice: 2500,
		discount: 24,
		category: "Men",
	},
];

export default recently_visited_data;
