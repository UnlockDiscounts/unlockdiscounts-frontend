import image from "../assets/zero_savings.png";

const zero_savings_data = [
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
];

export default zero_savings_data;
