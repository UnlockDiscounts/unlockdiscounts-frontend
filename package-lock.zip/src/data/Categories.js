
const Category = [
   "Sports",
   "Health",
   "Entertainment",
   "Education",
   "Science",
   "Travel",
   "Nature",
   "Food"
];
export default Category;