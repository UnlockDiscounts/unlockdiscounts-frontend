import image from "../assets/zara.jpg";
const Men = [
	{
		image: image,
		company: "Apple",
		type: "AirPods",
		price: 9999,
		prevPrice: 12999,
		discount: 23,
		category: "Electronics",
	},
    {
        image: image,
        company: "Tommy Hilfiger",
        type: "T-Shirt",
        price: 999,
        prevPrice: 1299,
        discount: 23,
        category: "Mens",
        
    },
    {
        image: image,
        company: "Adidas",
        type: "Shoes",
        price: 2999,
        prevPrice: 3999,
        discount: 25,
        category:'Mens'
    },
    {
        image: image,
        company: "Nike",
        type: "Shoes",
        price: 3999,
        prevPrice: 4999,
        discount: 20,
        category:'Mens'
    }
]
export default Men;