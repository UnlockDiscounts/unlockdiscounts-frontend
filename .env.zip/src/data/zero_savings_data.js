import image from "../assets/zero_savings.png";

const zero_savings_data = [
	{
		name: "Bank of Zero",
		image: image,
	},
	{
		name: "NoFunds Bank",
		image: image,
	},
	{
		name: "Empty Vault Financial",
		image: image,
	},
	{
		name: "BrokeSaver Bank",
		image: image,
	},
	{
		name: "EmptyPocket Credit Union",
		image: image,
	},
	{
		name: "ZeroBalance Trust",
		image: image,
	},
	{
		name: "NothingBank",
		image: image,
	},
	{
		name: "The Hollow Bank",
		image: image,
	},
	{
		name: "Fundless Financial",
		image: image,
	},
];

export default zero_savings_data;
