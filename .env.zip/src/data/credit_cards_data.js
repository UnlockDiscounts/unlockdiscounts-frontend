import image from "../assets/credit_card.png";

const credit_cards_data = [
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
	{
		image: image,
	},
];

export default credit_cards_data;
